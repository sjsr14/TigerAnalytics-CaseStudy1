package com.ProductAppP1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.UIModels.UILoginModel;
import com.UIModels.UIProductModel;

@Controller
public class SearchProductController {
	//searchProduct
	@RequestMapping(value="/searchProduct", method=RequestMethod.POST)
	public ModelAndView getSearhcedProduct(@ModelAttribute("UIProductModel") UIProductModel uIProductModel, Model model) {
		System.out.println(" ================ SearchProductController 1 =================================");
		System.out.println("getUiproductname :: " +uIProductModel.getUiproductname());
		//model.addAttribute("uiusernameAttribute", uILoginModel.getUiusername());
		
		ModelAndView modelAndView = new ModelAndView("FetchedProduct");
		//mv.addObject(attributeValue)
		//modelAndView.addObject("uiusernameAttributeMv", uILoginModel.getUiusername());
		
		return modelAndView;
	}

}
