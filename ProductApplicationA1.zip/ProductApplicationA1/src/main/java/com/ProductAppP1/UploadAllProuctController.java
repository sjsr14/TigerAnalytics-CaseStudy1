package com.ProductAppP1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.UIModels.UILoginModel;

@Controller
public class UploadAllProuctController {
	
	@Autowired
	UploadAllProductService uploadAllProductService;
	
	@RequestMapping(value="/uploadAllProduct" , method=RequestMethod.GET)
	public ModelAndView getLoginPage() {
		System.out.println(" ========= LoginController ==== login  ==============");
		try {
			uploadAllProductService.loadCSV();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Welcome1");
	}

}
