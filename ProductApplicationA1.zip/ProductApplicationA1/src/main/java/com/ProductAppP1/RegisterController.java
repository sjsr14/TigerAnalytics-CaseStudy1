package com.ProductAppP1;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ModelAndViewMethodReturnValueHandler;

import com.UIModels.UILoginUSer;

//import com.UIModels.UILoginUSer;

@Controller
//@ComponentScan(basePackages= {" com.ConfigUtils","com.UIModels"})
public class RegisterController {
	
	@RequestMapping(value = "/completeRegister", method = RequestMethod.POST)
    public String registration(@ModelAttribute("UILoginUSer") UILoginUSer UILoginUSer, BindingResult result, ModelMap model)  { 
	
		System.out.println(" ========= RegisterController ==== registration  ====== POST ========");
		//model.addAttribute("loginUser" , new UILoginUSer());
		model.addAttribute("username", UILoginUSer.getUsername());
		model.addAttribute("password", UILoginUSer.getPassword());
		model.addAttribute("reneteredpassword", UILoginUSer.getReneteredpassword());
		System.out.println(" loginUser.getUsername :: " + UILoginUSer.getUsername());
		System.out.println(" loginUser.getPassword :: " + UILoginUSer.getPassword());
		System.out.println(" loginUser.getReneteredpassword :: " +UILoginUSer.getReneteredpassword());
		if (result.hasErrors()) {
			return "register";
		}
		
		return "Welcome";
		
	}
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public ModelAndView  getRegistrationPage() {
		System.out.println(" ========= LoginController ==== register  ============== ");
		
		return new ModelAndView("register", "UILoginUSer", new UILoginUSer());
	}

}
