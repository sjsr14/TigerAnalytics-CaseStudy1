package com.ProductAppP1;

import java.util.List;

import org.springframework.batch.item.*;

public class ProductJdbcItemWriter implements ItemWriter<Product> {
	
	private static final String INSERT_PRODUCT = "insert into product "+
			"(id,name,description,price) values(?,?,?,?)";
			private static final String UPDATE_PRODUCT = "update product set "+
			"name=?, description=?, price=? where id=?";
		/*	private JdbcTemplate jdbcTemplate;
			public ProductJdbcItemWriter(DataSource ds) {
				this.jdbcTemplate = new JdbcTemplate(ds);
			} */
			public ProductJdbcItemWriter() {
				
			}
			public void write(List<? extends Product> items) throws Exception {
				
				System.out.println("============ Writer 1===============");
				
				 for (Product item : items) {
					 System.out.println("============ Writer 2 ===============" +item.toString());
					/*int updated = jdbcTemplate.update(
					UPDATE_PRODUCT,
					item.getName(),item.getDescription(),
					item.getPrice(),item.getId()
					);
					if (updated == 0) {
					jdbcTemplate.update(
					INSERT_PRODUCT,
					item.getId(),item.getName(),
					item.getDescription(),item.getPrice()
					);
					}*/
				}  
			}
}
