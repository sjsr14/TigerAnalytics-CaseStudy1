package com.ProductAppP1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class LoginDaoImpl {
	
	//@Autowired
	//public JdbcTemplate jdbcTemplate;
	
	public boolean isUserAuthticate(String username) {
		//jdbcTemplate.query("", rowMapper);
		
		return true;
	}

}
