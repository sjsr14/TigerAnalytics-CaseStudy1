package com.ProductAppP1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

//import com.ConfigUtils.ProductRootConfig;
//import com.ConfigUtils.ProductWebConfig;



@Component
//@Configuration
//@Import(ProductWebConfig.class)
//@ComponentScan
//@ComponentScan(basePackages={"com.ConfigUtils"})
public class ProductDispatcherServlet extends AbstractAnnotationConfigDispatcherServletInitializer{
	
	@Override
	protected  String[] getServletMappings() {
		System.out.println("   ======== getServletMappings===========1 =====     ");
		return new String[] {"/"};
	}
	
	@Override 
	protected  Class<?>[] getRootConfigClasses() {
		System.out.println("   ======== getRootConfigClasses===========2 =====     ");
		return new Class<?> [] {ProductRootConfig.class};
	}
	
	@Override 
	protected  Class<?>[] getServletConfigClasses() {
		System.out.println("   ======== getServletConfigClasses===========3 =====     ");
		return new Class<?>[] {ProductWebConfig.class};
	}

	
}
