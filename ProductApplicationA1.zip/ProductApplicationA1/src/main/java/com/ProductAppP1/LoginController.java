package com.ProductAppP1;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ModelAndViewMethodReturnValueHandler;

import com.UIModels.UILoginModel;
import com.UIModels.UIProductModel;


@Controller
//@ComponentScan(basePackages= {" com.ConfigUtils","com.UIModels"})
public class LoginController {
	
	//@Autowired
	ProductRootConfig productRootConfig;
	
	@Autowired
	LoginServiceImpl LoginServiceImpl;
		
	
	/*@RequestMapping(value="/submitLogin", method=RequestMethod.POST)
	public ModelAndView getWelcome(@ModelAttribute("UILoginModel") UILoginModel uILoginModel, Model model) {
		System.out.println(" ================ LoginController 1 =================================");
		System.out.println("Username :: " +uILoginModel.getUiusername());
		System.out.println("Password :: " +uILoginModel.getUipassword());
		System.out.println(" ================ LoginController 2 =================================");
		
		//model.addAttribute("uiusernameAttribute", uILoginModel.getUiusername());
		
		ModelAndView modelAndView = new ModelAndView("Welcome");
		//mv.addObject(attributeValue)
		//modelAndView.addObject("uiusernameAttributeMv", uILoginModel.getUiusername());
		
		return modelAndView;
	//	return "Welcome";
	}*/
	
	@RequestMapping(value="/submitLogin", method=RequestMethod.POST)
	public ModelAndView getWelcome(@ModelAttribute("UILoginModel") UILoginModel uILoginModel, Model model) {
		System.out.println(" ================ LoginController 1 =================================");
		System.out.println("Username :: " +uILoginModel.getUiusername());
		System.out.println("Password :: " +uILoginModel.getUipassword());
		boolean result = LoginServiceImpl.isAuthenticated(uILoginModel.getUiusername(), uILoginModel.getUipassword());
		
		ModelAndView modelAndView;
		if (result == true) {
			System.out.println(" ================ LoginController 2 =================================");
			modelAndView= new ModelAndView("Welcome", "UIProductModel", new UIProductModel());
		}
		else {
			System.out.println(" ================ LoginController 3 =================================");
			modelAndView = new ModelAndView("error");
		}
		System.out.println(" ================ LoginController 4 =================================");
		
		return modelAndView;

	}
	
	@RequestMapping(value="/Login" , method=RequestMethod.GET)
	public ModelAndView getLoginPage() {
		System.out.println(" ========= LoginController ==== login  ==============");
		
		return new ModelAndView("login", "UILoginModel", new UILoginModel());
	}
	

}

