package com.ProductAppP1;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@EnableWebMvc
@Configuration
@Component
@ComponentScan
//@ComponentScan(basePackages= {"com.Controllers"," com.ConfigUtils","com.ProductAppP1"})
//@Import(ProductRootConfig.class)
public class ProductWebConfig extends WebMvcConfigurerAdapter{
	
	//@Autowired
	//AppSecurity AppSecurity;
	
	
	@Bean
	public ViewResolver viewResolver() {
		System.out.println(" ====== viewResolver ==== 1 ====");
		InternalResourceViewResolver view = new InternalResourceViewResolver();
		view.setPrefix("/WEB-INF/views/");
		view.setSuffix(".jsp");
		view.setExposeContextBeansAsAttributes(true);
		System.out.println(" ====== viewResolver ==== 2 ====");
		return view;
	}
	
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configure) {
		configure.enable();
	}

	@Bean
	public MultipartResolver multipartResolver() throws IOException {
	return new StandardServletMultipartResolver();
	}
}
