package com.ProductAppP1;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class UploadAllProductService {

	
	public void loadCSV() throws Exception{
		System.out.println(" ============= UploadAllProductService == 1  ===========");
		String[] springConfig  =  { "jobConfig.xml" };  
	      
	      // Creating the application context object        
	      ApplicationContext context = new ClassPathXmlApplicationContext(springConfig);  
	      
	      // Creating the job launcher 
	      JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher"); 
	   
	      // Creating the job 
	      Job job = (Job) context.getBean("importProducts"); 
	   
	      // Executing the JOB 
	      JobExecution execution = jobLauncher.run(job, new JobParameters());
	      System.out.println("Exit Status : " + execution.getStatus()); 
	      System.out.println(" ============= UploadAllProductService 22  ===========");
	}
	
}
