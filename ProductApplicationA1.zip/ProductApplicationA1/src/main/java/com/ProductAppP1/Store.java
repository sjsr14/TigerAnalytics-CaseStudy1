package com.ProductAppP1;

public class Store {

}
