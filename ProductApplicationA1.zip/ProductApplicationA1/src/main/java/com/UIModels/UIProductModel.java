package com.UIModels;

public class UIProductModel {
	
	private String uiproductname;
	
	public UIProductModel() {
		// TODO Auto-generated constructor stub
	}

	public String getUiproductname() {
		return uiproductname;
	}

	public void setUiproductname(String uiproductname) {
		this.uiproductname = uiproductname;
	}
	
	

}
