package com.UIModels;

import javax.validation.constraints.*;


public class UILoginUSer {

//	@NotNull
	private String username;
	
//	@NotNull
	private String password;
	
//	@NotNull
	private String reneteredpassword ;
	
	public UILoginUSer() {
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getReneteredpassword() {
		return reneteredpassword;
	}

	public void setReneteredpassword(String reneteredpassword) {
		this.reneteredpassword = reneteredpassword;
	}
	
	
}
