package com.UIModels;

public class UILoginModel {
	
	private String uiusername;
	private String uipassword ;
	
	public UILoginModel() {
		// TODO Auto-generated constructor stub
	}

	public String getUiusername() {
		return uiusername;
	}

	public void setUiusername(String uiusername) {
		this.uiusername = uiusername;
	}

	public String getUipassword() {
		return uipassword;
	}

	public void setUipassword(String uipassword) {
		this.uipassword = uipassword;
	}
	
}
